- 👋 Hi, I’m @yohannesleul24
- 👀 I’m interested in programmming 
- 🌱 I’m currently learning software engineering
- 💞️ I’m looking to collaborate on web development
- 📫 How to reach me johannesleul24@gmail.com

<!---
yohannesleul24/yohannesleul24 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
